# All Items methodology

::: clayrs.recsys.AllItemsMethodology
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true
