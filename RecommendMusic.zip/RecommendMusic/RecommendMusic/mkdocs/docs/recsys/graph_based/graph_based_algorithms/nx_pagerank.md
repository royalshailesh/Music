# Page Rank


::: clayrs.recsys.graph_based_algorithm.page_rank.nx_page_rank.NXPageRank
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true