# Graph Based RecSys

::: clayrs.recsys.recsys.GraphBasedRS
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true