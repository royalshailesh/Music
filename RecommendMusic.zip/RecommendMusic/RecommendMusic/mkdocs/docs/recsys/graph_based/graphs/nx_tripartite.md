# Tripartite Graph

Please remember that this class is a subclass of [NXBipartiteGraph][clayrs.recsys.NXBipartiteGraph],
so it inherits all its methods. You can check their documentation as well!

::: clayrs.recsys.graphs.nx_implementation.nx_tripartite_graphs.NXTripartiteGraph
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true
