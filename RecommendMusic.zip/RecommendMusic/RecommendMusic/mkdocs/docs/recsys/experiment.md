# Experiment class

::: clayrs.recsys.ContentBasedExperiment
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true

::: clayrs.recsys.GraphBasedExperiment
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true
