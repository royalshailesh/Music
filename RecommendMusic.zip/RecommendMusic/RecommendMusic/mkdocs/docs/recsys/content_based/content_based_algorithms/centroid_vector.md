# Centroid Vector

::: clayrs.recsys.content_based_algorithm.centroid_vector.CentroidVector
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true

---

## Similarities implemented

The following are similarities you can use in the `similarity` parameter of the `CentroidVector` class

::: clayrs.recsys.content_based_algorithm.centroid_vector.similarities.CosineSimilarity
    handler: python
    options:
        heading_level: 3
        show_root_toc_entry: true
        show_root_heading: true
