

::: clayrs.recsys.content_based_algorithm.index_query.index_query.IndexQuery
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true