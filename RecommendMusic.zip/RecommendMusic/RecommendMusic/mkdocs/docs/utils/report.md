# Report class

::: clayrs.utils.Report
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true
