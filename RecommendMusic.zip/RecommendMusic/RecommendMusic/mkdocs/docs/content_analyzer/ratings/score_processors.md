# Score Processors

::: clayrs.content_analyzer.ratings_manager.NumberNormalizer
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true

::: clayrs.content_analyzer.ratings_manager.TextBlobSentimentAnalysis
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true