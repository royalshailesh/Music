# Ratings class

The `Ratings` class is the main responsible for importing a dataset containing interactions between users and items

::: clayrs.content_analyzer.ratings_manager.Ratings
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true
