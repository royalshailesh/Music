# Properties from local dataset

::: clayrs.content_analyzer.PropertiesFromDataset
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true
