# Raw Source Wrappers

::: clayrs.content_analyzer.raw_information_source
    handler: python
    options:
        filters:
            - "!^_[^_]"
            - "!^RawInformationSource$"
