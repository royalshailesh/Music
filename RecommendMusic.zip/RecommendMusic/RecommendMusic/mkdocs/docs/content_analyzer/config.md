# Content Analyzer Config

::: clayrs.content_analyzer.config
    handler: python


## Content Analyzer Class

::: clayrs.content_analyzer.ContentAnalyzer
    handler: python
    options:
        heading_level: 3
        show_root_toc_entry: true
        show_root_heading: true
