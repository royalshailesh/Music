# Content Analyzer Config

::: clayrs.content_analyzer.SkLearnTfIdf
    handler: python
    options:
        show_root_toc_entry: true
        show_root_heading: true

::: clayrs.content_analyzer.WhooshTfIdf
    handler: python
    options:    
        show_root_toc_entry: true
        show_root_heading: true