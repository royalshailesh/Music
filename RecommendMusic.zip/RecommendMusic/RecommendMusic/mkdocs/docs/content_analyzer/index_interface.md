# Index interface

::: clayrs.content_analyzer.memory_interfaces.text_interface
    handler: python
