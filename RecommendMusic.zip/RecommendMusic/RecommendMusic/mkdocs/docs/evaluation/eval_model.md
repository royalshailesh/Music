# Eval Model class

::: clayrs.evaluation.eval_model
    handler: python
