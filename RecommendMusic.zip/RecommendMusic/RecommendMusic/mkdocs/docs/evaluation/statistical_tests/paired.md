# Paired statistical tests

::: clayrs.evaluation.statistical_test.PairedTest
    handler: python
    options:
      show_root_toc_entry: true
      show_root_heading: true

::: clayrs.evaluation.statistical_test.Ttest
    handler: python
    options:
      show_root_toc_entry: true
      show_root_heading: true

::: clayrs.evaluation.statistical_test.Wilcoxon
    handler: python
    options:
      show_root_toc_entry: true
      show_root_heading: true