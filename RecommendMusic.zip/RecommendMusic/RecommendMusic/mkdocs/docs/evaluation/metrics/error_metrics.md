# Error metrics

Error metrics evaluate 'how wrong' the recommender system was in predicting a rating

::: clayrs.evaluation.metrics.error_metrics
    handler: python
    options:
        filters:
        - "!^_[^_]"
        - "!^ErrorMetric$"