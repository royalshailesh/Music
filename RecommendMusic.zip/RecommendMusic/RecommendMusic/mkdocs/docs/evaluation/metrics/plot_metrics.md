# Plot metrics

Plot metrics save a plot in the chosen output directory

::: clayrs.evaluation.metrics.plot_metrics
    handler: python
    options:
        filters:
        - "!^_[^_]"
        - "!^PlotMetric$"
        - "!.*def.*"