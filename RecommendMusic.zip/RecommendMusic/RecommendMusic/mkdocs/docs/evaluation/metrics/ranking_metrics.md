# Ranking metrics

Ranking metrics evaluate the quality of the recommendation lists

::: clayrs.evaluation.metrics.ranking_metrics
    handler: python
    options:
        filters:
        - "!^_[^_]"
        - "!^RankingMetric$"
        - "!.*def.*"