class FeatureSelectionException(Exception):
    """
    Generic exception used inside the FeatureSelectionAlgorithm
    """
    pass
