from .nx_bipartite_graphs import NXBipartiteGraph
from .nx_tripartite_graphs import NXTripartiteGraph
from .nx_full_graphs import NXFullGraph
