import nest_asyncio
nest_asyncio.apply()  # fix IPython multiprocessing error
