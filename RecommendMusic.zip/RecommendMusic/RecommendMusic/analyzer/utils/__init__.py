from .load_content import load_content_instance
from .report import Report
