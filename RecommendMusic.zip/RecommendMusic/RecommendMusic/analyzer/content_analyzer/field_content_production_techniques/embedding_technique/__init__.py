from .combining_technique import Centroid, Sum, SingleToken
from .embedding_technique import WordEmbeddingTechnique, SentenceEmbeddingTechnique, DocumentEmbeddingTechnique, \
    Word2SentenceEmbedding, Sentence2DocEmbedding, Word2DocEmbedding, Sentence2WordEmbedding
